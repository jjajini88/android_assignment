package com.laura.lauraassignment;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    AppObject obj;
    int i;
    TextView textView;

    //Notifications
    Intent notificationIntent;
    int icon;
    CharSequence tickerText;
    CharSequence contentTitle;
    CharSequence contentText;
    int Notification_id = 1;
    NotificationManager manager;

    PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        obj = (AppObject) getApplication();
        i = (obj.i);
        textView = (TextView) findViewById(R.id.textView);
        textView.setText("Our sample number is " + i);

        notificationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.ca/?gms_check")).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        icon = R.drawable.ic_launcher;
        tickerText = "TICKER HERE";
        contentTitle = "TEXT Title";
        contentText = "TEXT Content";

    }

    public void start(View view) {
        Intent intent = new Intent(getBaseContext(), CustomService.class);
        startService(intent);
    }


    public void stop(View view) {
        Intent intent = new Intent(getBaseContext(), CustomService.class);
        stopService(intent);
    }

    public void intent(View view) {
        int flag = PendingIntent.FLAG_UPDATE_CURRENT;
        pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flag);
    }

    public void notification(View view) {
        Notification notification = new Notification.Builder(this)
                .setSmallIcon(icon)
                .setTicker(tickerText)
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();
        manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        manager.notify(Notification_id, notification);
    }

    public void cancel(View view) {
        manager.cancel(Notification_id);
    }
}
