package com.laura.lauraassignment;

import android.app.Application;
import android.util.Log;

/**
 * Created by Administrator on 2017-03-24.
 */

public class AppObject extends Application {
    int i = 10000;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("laura", "App Started Now");
    }

    public void globalMethod(String message) {
        Log.d("laura", message);
    }
}
