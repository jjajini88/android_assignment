package com.laura.lauraassignment;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Administrator on 2017-03-24.
 */

public class CustomService extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("laura", "CustomService:onCreate");
        Toast.makeText(getApplicationContext(), "CustomService:onCreate", Toast.LENGTH_LONG).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("laura", "CustomService:onStartCommand");
        // return super.onStartCommand(intent, flags, startId);
        Toast.makeText(getApplicationContext(), "CustomService:onStartCommand", Toast.LENGTH_LONG).show();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("laura", "CustomService:onDestroy");
        Toast.makeText(getApplicationContext(), "CustomService:onDestroy", Toast.LENGTH_LONG).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d("laura", "CustomService:onBind");
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("laura", "CustomService:onUnbind");
        return super.onUnbind(intent);
    }
}
