package com.isp1004.daniel.assignmentmar23daniel;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    GlobalApp globalApp;

    //Notifications
    Intent notificationIntent;
    int icon;
    CharSequence tickerText;
    CharSequence contentTitle;
    CharSequence contentText;
    int Notification_id = 1;
    NotificationManager manager;

    PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        globalApp = (GlobalApp)getApplication();
    }

    public void onCheckNetwork(View view) {
        // To Use System Manager. Especially, ConnectivityManager.
        ConnectivityManager connectivityManager = (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        NetworkInfo.DetailedState detailedState = networkInfo.getDetailedState();
        String checkMessage = detailedState.toString();
        Log.d("Main", detailedState.toString());

        // To get current date & time
        SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss.SSS");
        String current_time_str = time_formatter.format(System.currentTimeMillis());

        // To Use Notification
        notificationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.ca/?gms_check")).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        icon = R.drawable.ic_launcher;
        tickerText = checkMessage;
        contentTitle = "Check Network status.";
        contentText = checkMessage + "[" + current_time_str + "]";

        int flag = PendingIntent.FLAG_UPDATE_CURRENT;
        pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flag);

        Notification notification = new Notification.Builder(this)
                .setSmallIcon(icon)
                .setTicker(tickerText)
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();
        manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        manager.notify(Notification_id, notification);

        // To use Application Object
        globalApp.setNotificationDt(current_time_str);
    }

    public void onViewCheckTime(View view) {
        Intent intent = new Intent(this, TimeListActivity.class);
        startActivity(intent);
    }
}
