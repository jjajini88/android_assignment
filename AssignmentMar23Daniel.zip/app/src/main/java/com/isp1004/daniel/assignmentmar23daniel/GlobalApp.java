package com.isp1004.daniel.assignmentmar23daniel;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-03-22.
 */

public class GlobalApp extends Application {
    private List<String> list;

    @Override
    public void onCreate() {
        super.onCreate();
        list = new ArrayList<String>();
    }

    public List<String> getList() {
        return list;
    }

    public void setNotificationDt(String strDt) {
        list.add(strDt);
    }
}
