package com.isp1004.daniel.assignmentmar23daniel;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class TimeListActivity extends AppCompatActivity {

    GlobalApp globalApp;
    ListView checkTimeList;
    List<String> globalCheckTimeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_list);

        globalApp = (GlobalApp) getApplication();
        globalCheckTimeList = globalApp.getList();

        checkTimeList = (ListView) findViewById(R.id.lv_check_time);
        checkTimeList.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>()));

        new MyTask().execute();
    }

    class MyTask extends AsyncTask<Void, String, String> {
        ArrayAdapter<String> adapter;

        @Override
        protected void onPreExecute() {
            adapter = (ArrayAdapter<String>)checkTimeList.getAdapter();
        }

        @Override
        protected String doInBackground(Void... params) {
            for (Object datetime : globalCheckTimeList) {
                publishProgress((String)datetime);
            }
            return "All The Date Time Were Added";
        }

        @Override
        protected void onProgressUpdate(String... values) {
            adapter.add(values[0]);
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }
}


